
  # Civic Lab High-Fidelity Prototype

  This is a code bundle for Civic Lab High-Fidelity Prototype. The original project is available at https://www.figma.com/design/RhKqzm9pBlj8WmiH3DPE22/Civic-Lab-High-Fidelity-Prototype.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  